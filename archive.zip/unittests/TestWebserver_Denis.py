import unittest
import time
import json

from app import webserver, routes

class TestWebserver(unittest.TestCase):
    def setUp(self):
        """
            This method is executed before each test case.
            It initializes the web server and the task runner.
        """
        self.webserver = webserver
        self.webserver.testing = True
        self.test_client = self.webserver.test_client()
        # Store original shutting_down value to restore after tests
        self.original_shutting_down = getattr(self.webserver, 'shutting_down', False)
        # Ensure shutting_down is False at the start of each test
        self.webserver.shutting_down = False

    def tearDown(self):
        """
            This method is executed after each test case.
            It restores the original state of the webserver.
        """
        # Restore the original shutting_down value
        self.webserver.shutting_down = self.original_shutting_down

    def test_1_jobs_request(self):
        """
            This test checks if the jobs request is working correctly
            by issuing a request to the API, checking if the response is valid,
            waiting for a short time, and then checking if the job is done running.
            It also checks if the job id is present in the response.
        """
        # issue a request at the api
        with self.test_client as client:
            post_req = client.post("/api/states_mean", json={
                "question": "Percent of adults who engage in no leisure-time physical activity",
            })

            # check if the response is valid
            self.assertEqual(post_req.status_code, 200)
            post_data = json.loads(post_req.data)
            self.assertIn("job_id", post_data)
            
            # get the job id
            job_id = post_data["job_id"]

            # perform a 0.5 second sleep and then check for the result
            time.sleep(0.5)
            get_req = client.get("/api/jobs")

            # get the "data" values from the json
            get_data = json.loads(get_req.data)
            self.assertIn("data", get_data)
            data = get_data["data"]

            # Verify job exists in response
            job_found = False
            for job_info in data:
                if str(job_id) in job_info:
                    job_found = True
                    break
                    
            self.assertTrue(job_found, f"Job {job_id} not found in the response data")

    def test_2_num_jobs(self):
        """
            This test checks if the number of jobs is working correctly
            by issuing a request to the API and checking if the response is valid.
            It also checks if the number of jobs is present in the response
            is of type int and is greater than or equal to 0.
        """
        with self.test_client as client:
            get_req = client.get("/api/num_jobs")
            
            # Check if the response is valid
            self.assertEqual(get_req.status_code, 200)
            
            # Parse the response
            get_data = json.loads(get_req.data)
            
            # Check if response has the expected structure
            self.assertEqual(get_data["status"], "done")
            
            # Check for either remaining_jobs or num_jobs in the response
            if "remaining_jobs" in get_data:
                num_jobs = get_data["remaining_jobs"]
            elif "num_jobs" in get_data:
                num_jobs = get_data["num_jobs"]
            else:
                self.fail("Neither 'remaining_jobs' nor 'num_jobs' found in response")
                
            # Check if the number of jobs is of type int
            self.assertIsInstance(num_jobs, int)
            
            # Check if the number of jobs is greater than or equal to 0
            self.assertGreaterEqual(num_jobs, 0)

    def test_3_graceful_shutdown(self):
        """
            This test checks if the graceful shutdown is working correctly
            by issuing a shutdown request to the API and checking if the response is valid,
            and then issuing a normal request to the API and checking if the response is valid,
            and if it is of type "error" and the reason is "shutting down".
        """
        with self.test_client as client:
            # issue a shutdown request
            get_req = client.get("/api/graceful_shutdown")

            # check if the response is valid
            self.assertEqual(get_req.status_code, 200)
            
            # Parse response data
            get_data = json.loads(get_req.data)
            
            # check if the shutdown status is in the json
            self.assertIn("status", get_data)

            # get the shutdown status
            shutdown_status = get_data["status"]

            # check if the status is "done" or "running" 
            self.assertIn(shutdown_status, ["done", "running"])

            # Verify the shutting_down flag was set
            self.assertTrue(self.webserver.shutting_down)

            # try to issue a request after the shutdown
            post_req = client.post("/api/states_mean", json={
                "question": "Percent of adults who engage in no leisure-time physical activity",
            })
            
            # check if the response is valid
            self.assertEqual(post_req.status_code, 200)
            
            # Parse response data
            post_data = json.loads(post_req.data)

            # check if the status is in the json
            self.assertIn("status", post_data)
            
            # get the status
            shutdown_status = post_data["status"]
            
            # check if the status is "error"
            self.assertEqual(shutdown_status, "error")

            # check if the error reason is in the json
            self.assertIn("reason", post_data)
            
            # get the error reason
            error_reason = post_data["reason"]
            
            # check if the reason is "shutting down"
            self.assertEqual(error_reason, "shutting down")

    def test_4_get_results_invalid_job_id(self):
        """
            This test checks if the get_results endpoint correctly handles invalid job IDs.
        """
        with self.test_client as client:
            # Test with job_id > job_counter
            invalid_id_high = 9999
            response = client.get(f"/api/get_results/{invalid_id_high}")
            self.assertEqual(response.status_code, 200)
            
            response_data = json.loads(response.data)
            expected_response = {
                "reason": "Invalid job_id",
                "status": "error"
            }
            self.assertEqual(response_data, expected_response)
            
            # Test with job_id < 1
            invalid_id_low = 0
            response = client.get(f"/api/get_results/{invalid_id_low}")
            self.assertEqual(response.status_code, 200)
            
            response_data = json.loads(response.data)
            self.assertEqual(response_data, expected_response)

    def test_5_post_methods_rejection(self):
        """
            This test checks that GET-only endpoints reject POST requests correctly.
        """
        with self.test_client as client:
            # Test POST request to num_jobs endpoint (GET only)
            response = client.post("/api/num_jobs")
            self.assertEqual(response.status_code, 405)
            
            # Test POST request to get_results endpoint (GET only)
            response = client.post("/api/get_results/1")
            self.assertEqual(response.status_code, 405)
            
            # Test POST request to graceful_shutdown endpoint (GET only)
            response = client.post("/api/graceful_shutdown")
            self.assertEqual(response.status_code, 405)

if __name__ == '__main__':
    unittest.main()